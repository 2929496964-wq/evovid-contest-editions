EvoDock Storyboard Agent
DEMO FIXTURE: deterministic template, no provider call
Open preview.mp4 to play. Local geometric motion graphics, not neural video generation.
project.json contains brief, revision history and audit trace. Share only after checking its contents.
Trace hashes prove local integrity, not an independent provider attestation.
